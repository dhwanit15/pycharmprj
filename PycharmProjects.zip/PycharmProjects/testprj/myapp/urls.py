from django.contrib import admin
from myapp import views
import django.conf.urls
from django.contrib.auth.views import login
urlpatterns = [
    django.conf.urls.url(r'^signup/$', views.signup, name='signup'),
    django.conf.urls.url(r'^bookcleaner/$', views.bookcleaner, name='bookcleaner'),


]
