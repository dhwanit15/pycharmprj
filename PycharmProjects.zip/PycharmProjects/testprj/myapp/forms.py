from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.forms import ModelForm
from myapp.models import Customer,Booking

# class HomeFrom(forms.Form):
#     first_name = forms.CharField(max_length=30, required=False, help_text='Optional.')
#     last_name = forms.CharField(max_length=30, required=False, help_text='Optional.')



class Customerform(forms.ModelForm):
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    phone_number = forms.CharField(max_length=254,required=True)

    class Meta:
        model = Customer
        fields = ('first_name', 'last_name', 'phone_number',)

class booking(forms.ModelForm):
    customer = forms.CharField(max_length=30, required=True)
    cleaner = forms.CharField(max_length=30, required=True)
    # city = forms.CharField(max_length=30, required=True)
    date = forms.CharField(max_length=254,required=True)

    class Meta:
        model = Booking
        fields = ('customer', 'cleaner','date',)

