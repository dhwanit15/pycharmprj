# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.views.generic import View
from django.views.generic import TemplateView, ListView
from django.shortcuts import render,redirect
# from myapp.forms import HomeFrom ,SignUpForm,registerform,LoginForm
from myapp.forms import Customerform
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login, authenticate
from .models import Customer,Booking,Cleaner,City
import requests,json,urllib2,ast
import csv,json
from django.core.paginator import Paginator,EmptyPage,InvalidPage,PageNotAnInteger
import matplotlib.pyplot as plt
from django.http import HttpResponse,JsonResponse
from rest_framework.views import APIView
from rest_framework.response import Response




def signup(request):
    cities=[]
    if request.method == 'POST':
        form = Customerform(request.POST)
        if form.is_valid():
            phone_number=request.POST['phone_number']
            first_name=request.POST['first_name']
            city=City.objects.all()
            for i in city:
                cities.append(i)
            if Customer.objects.filter(phone_number=phone_number).exists():
                print "Data Present"
                return render(request, 'booking.html', {'first_name': first_name,'phone_number':phone_number,'city_name':cities})
            else:
                form.save()
                return render(request, 'booking.html', {'first_name': first_name,'phone_number':phone_number,'city_name':cities})
            return HttpResponse("User created successfully!")
    else:
        form = Customerform()
        return render(request, 'signup.html', {'form': form})

def bookcleaner(request):
    if request.method == "POST":
        customer = request.POST["customer"]
        phone = request.POST["phone_number"]
        city_name = request.POST["city"]
        date = request.POST["Date"]
        tbl_city=City.objects.all()
        for i in tbl_city:
            print "!!!!!!!!!!!!!!!!!!!!!!!",i
            if city_name == i['city_name']:
                print "###################################",i['id']
                cityid = i['id']

        cleaner=Cleaner.objects.all()
        
        for i in Cleaner:
            if i['city_id'] == cityid:
                cleaner=i['last_name'] + ' '+i['first_name']
                form=Booking(request.POST)
                form.save()
