# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models


class Customer(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    phone_number = models.CharField(max_length=30)

    # class Meta:
    #     db_table = 'myapp_company'
class Booking(models.Model):
    customer = models.CharField(max_length=30)
    cleaner = models.CharField(max_length=30)
    date = models.CharField(max_length=30)

class Cleaner(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    quality_score = models.CharField(max_length=30)

class City(models.Model):
	city_name=models.CharField(max_length=30)




